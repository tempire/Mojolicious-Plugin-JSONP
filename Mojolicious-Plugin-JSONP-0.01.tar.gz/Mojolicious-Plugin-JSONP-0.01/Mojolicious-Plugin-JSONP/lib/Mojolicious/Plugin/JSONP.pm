use strict;
use warnings;
package Mojolicious::Plugin::JSONP;

1;
